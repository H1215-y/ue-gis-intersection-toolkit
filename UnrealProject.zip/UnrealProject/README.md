# UE 工程副本

项目位于 `road-intersection/`，入口文件为 `路口0902.uproject`，EngineAssociation 为 Unreal Engine 5.8。

仓库保留了项目的 `Config/` 与 `Content/`（包括 `0904.umap` 和材质资产），未复制 `Saved/`、`Intermediate/`、`DerivedDataCache/` 或 Cesium 请求缓存。另需安装与 UE 5.8 兼容的 Cesium for Unreal 插件，并在目标电脑配置 Cesium ion 访问。
